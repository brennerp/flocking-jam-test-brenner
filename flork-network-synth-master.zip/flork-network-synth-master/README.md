The first Florkestra instrument: a networked synth that can be controlled by different clients using osc.js and Web Sockets.

Instructions
------------

1. Run <code>npm install</code>
2. <code>cd web</code>
3. <code>bower install</code>
4. <code>cd ..</code>
5. Start the server by running <code>node .</code>
6. In your browser, load the synth page at <code>http://localhost:8081/synth</code>
7. Load the xy controller at <code>http://localhost:8081/xy</code>
